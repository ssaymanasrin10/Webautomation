package pages;

import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;


import drivers.PageDriver;
import utilities.CommonMethods;

public class HomePage extends CommonMethods {

	public HomePage() {
		PageFactory.initElements(PageDriver.getCurrentDriver(),this);
	}
	
	//@FinBy = driver.findelement(By.)
	@FindAll({
		@FindBy(xpath = "//a[contains(text(),'Sign in')]"),
		@FindBy(xpath = "//a[@title= 'Log in to your customer Account']")
	})
	WebElement signIn;
	
	@FindAll({
		@FindBy(id = "email_create"),
		@FindBy(xpath = "//input[@name= 'email_create']")
	})
	WebElement emailAddress;
	
	
	@FindAll({
		@FindBy(id = "SubmitCreate"),
		@FindBy(xpath = "//button[@id= 'SubmitCreate']")
	})
	WebElement accountButton;
	
	public void clickOnSignIn() {
		signIn.click();
	}
	
	public void sendEmail() {
		sendText(emailAddress,emailGenerate());
		timeOut(2000);
	}
	
	public void clickOnAccountButton() {
		accountButton.click();
		timeOut(5000);
	}
}
